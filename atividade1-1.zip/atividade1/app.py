import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret'
db_path = os.path.join(os.path.dirname(__file__), 'atividade.db')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Classe de usuário
class Usuario(db.Model):
    __tablename__ = "usuario"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(256), nullable=False)
    senha = db.Column(db.String(256), nullable=False)

    anuncios = db.relationship("Anuncio", backref="usuario", cascade="all, delete-orphan")
    perguntas = db.relationship("Pergunta", backref="usuario", cascade="all, delete-orphan")
    compras = db.relationship("Compra", backref="usuario", cascade="all, delete-orphan")
    favoritos = db.relationship("Favorito", backref="usuario", cascade="all, delete-orphan")

    def __init__(self, nome=None, email=None, senha=None, **kwargs):
        super().__init__(**kwargs)
        if nome is not None:
            self.nome = nome
        if email is not None:
            self.email = email
        if senha is not None:
            self.senha = senha


# Classe de categoria
class Categoria(db.Model):
    __tablename__ = "categoria"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(256), nullable=False)
    descricao = db.Column(db.String(256), nullable=False)

    anuncios = db.relationship("Anuncio", backref="categoria", cascade="all, delete-orphan")

    def __init__(self, nome=None, descricao=None, **kwargs):
        super().__init__(**kwargs)
        if nome is not None:
            self.nome = nome
        if descricao is not None:
            self.descricao = descricao

# Classe de anúncio
class Anuncio(db.Model):
    __tablename__ = "anuncio"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(256), nullable=False)
    descricao = db.Column(db.String(256), nullable=False)
    quantidade = db.Column(db.Integer, nullable=False, default=0)
    preco = db.Column(db.Float, nullable=False, default=0.0)
    categoria_id = db.Column(db.Integer, db.ForeignKey("categoria.id"), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuario.id"), nullable=False)

    perguntas = db.relationship("Pergunta", backref="anuncio", cascade="all, delete-orphan")
    compras = db.relationship("Compra", backref="anuncio", cascade="all, delete-orphan")
    favoritos = db.relationship("Favorito", backref="anuncio", cascade="all, delete-orphan")

    def __init__(self, nome=None, descricao=None, quantidade=0, preco=0.0, categoria_id=None, usuario_id=None, **kwargs):
        super().__init__(**kwargs)
        if nome is not None:
            self.nome = nome
        if descricao is not None:
            self.descricao = descricao
        if quantidade is not None:
            self.quantidade = quantidade
        if preco is not None:
            self.preco = preco
        if categoria_id is not None:
            self.categoria_id = categoria_id
        if usuario_id is not None:
            self.usuario_id = usuario_id

# Classe de pergunta
class Pergunta(db.Model):
    __tablename__ = "pergunta"
    id = db.Column(db.Integer, primary_key=True)
    conteudo = db.Column(db.Text, nullable=False)
    data = db.Column(db.DateTime, default=datetime.utcnow)
    anuncio_id = db.Column(db.Integer, db.ForeignKey("anuncio.id"), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuario.id"), nullable=False)

    respostas = db.relationship("Resposta", backref="pergunta", cascade="all, delete-orphan")

    def __init__(self, conteudo=None, anuncio_id=None, usuario_id=None, data=None, **kwargs):
        super().__init__(**kwargs)
        if conteudo is not None:
            self.conteudo = conteudo
        if anuncio_id is not None:
            self.anuncio_id = anuncio_id
        if usuario_id is not None:
            self.usuario_id = usuario_id
        if data is not None:
            self.data = data

# Classe de resposta
class Resposta(db.Model):
    __tablename__ = "resposta"
    id = db.Column(db.Integer, primary_key=True)
    conteudo = db.Column(db.Text, nullable=False)
    data = db.Column(db.DateTime, default=datetime.utcnow)
    pergunta_id = db.Column(db.Integer, db.ForeignKey("pergunta.id"), nullable=False)

    def __init__(self, conteudo=None, pergunta_id=None, data=None, **kwargs):
        super().__init__(**kwargs)
        if conteudo is not None:
            self.conteudo = conteudo
        if pergunta_id is not None:
            self.pergunta_id = pergunta_id
        if data is not None:
            self.data = data

# Classe de compra
class Compra(db.Model):
    __tablename__ = "compra"
    id = db.Column(db.Integer, primary_key=True)
    quantidade = db.Column(db.Integer, nullable=False, default=1)
    preco_unitario = db.Column(db.Float, nullable=False, default=0.0)
    valor_total = db.Column(db.Float, nullable=False, default=0.0)
    data = db.Column(db.DateTime, default=datetime.utcnow)
    anuncio_id = db.Column(db.Integer, db.ForeignKey("anuncio.id"), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuario.id"), nullable=False)

    def __init__(self, quantidade=1, preco_unitario=0.0, valor_total=0.0, anuncio_id=None, usuario_id=None, data=None, **kwargs):
        super().__init__(**kwargs)
        if quantidade is not None:
            self.quantidade = quantidade
        if preco_unitario is not None:
            self.preco_unitario = preco_unitario
        if valor_total is not None:
            self.valor_total = valor_total
        if anuncio_id is not None:
            self.anuncio_id = anuncio_id
        if usuario_id is not None:
            self.usuario_id = usuario_id
        if data is not None:
            self.data = data

# Classe de favorito
class Favorito(db.Model):
    __tablename__ = "favorito"
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.DateTime, default=datetime.utcnow)
    anuncio_id = db.Column(db.Integer, db.ForeignKey("anuncio.id"), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuario.id"), nullable=False)

    def __init__(self, anuncio_id=None, usuario_id=None, data=None, **kwargs):
        super().__init__(**kwargs)
        if anuncio_id is not None:
            self.anuncio_id = anuncio_id
        if usuario_id is not None:
            self.usuario_id = usuario_id
        if data is not None:
            self.data = data


with app.app_context():
    db.create_all()

@app.route("/")
def index():
    return render_template('index.html', titulo="Menu Principal")


# CRUD de usuário
@app.route("/cad/usuario")
def usuario():
    usuarios = db.session.scalars(db.select(Usuario)).all()
    return render_template('usuario.html', usuarios=usuarios, titulo="Cadastro de Usuário")

@app.route("/usuario/criar", methods=['POST'])
def criar_usuario():
    novo_usuario = Usuario(
        nome=request.form.get('nome'),
        email=request.form.get('email'),
        senha=request.form.get('senha')
    )
    db.session.add(novo_usuario)
    db.session.commit()
    return redirect(url_for('usuario'))

@app.route("/usuario/editar/<int:id>", methods=['GET', 'POST'])
def editar_usuario(id):
    usuario_obj = db.get_or_404(Usuario, id)
    if request.method == 'POST':
        usuario_obj.nome = request.form.get('nome')
        usuario_obj.email = request.form.get('email')
        usuario_obj.senha = request.form.get('senha')
        db.session.commit()
        return redirect(url_for('usuario'))
    return render_template('editar_usuario.html', usuario=usuario_obj, titulo="Editar Usuário")

@app.route("/usuario/deletar/<int:id>")
def deletar_usuario(id):
    usuario_obj = db.get_or_404(Usuario, id)
    db.session.delete(usuario_obj)
    db.session.commit()
    return redirect(url_for('usuario'))


# CRUD de categoria
@app.route("/config/categoria")
def categoria():
    categorias = db.session.scalars(db.select(Categoria)).all()
    return render_template('categoria.html', categorias=categorias, titulo="Cadastro de Categoria")

@app.route("/categoria/criar", methods=['POST'])
def criar_categoria():
    nova_cat = Categoria(
        nome=request.form.get('nome'),
        descricao=request.form.get('descricao')
    )
    db.session.add(nova_cat)
    db.session.commit()
    return redirect(url_for('categoria'))

@app.route("/categoria/editar/<int:id>", methods=['GET', 'POST'])
def editar_categoria(id):
    cat_obj = db.get_or_404(Categoria, id)
    if request.method == 'POST':
        cat_obj.nome = request.form.get('nome')
        cat_obj.descricao = request.form.get('descricao')
        db.session.commit()
        return redirect(url_for('categoria'))
    return render_template('editar_categoria.html', categoria=cat_obj, titulo="Editar Categoria")

@app.route("/categoria/deletar/<int:id>")
def deletar_categoria(id):
    cat_obj = db.get_or_404(Categoria, id)
    db.session.delete(cat_obj)
    db.session.commit()
    return redirect(url_for('categoria'))


# CRUD de anúncio
@app.route("/cad/anuncio")
def anuncio():
    anuncios = db.session.scalars(db.select(Anuncio)).all()
    categorias = db.session.scalars(db.select(Categoria)).all()
    usuarios = db.session.scalars(db.select(Usuario)).all()
    return render_template('anuncio.html', anuncios=anuncios, categorias=categorias, usuarios=usuarios, titulo="Cadastro de Anúncio")

@app.route("/anuncios/listar")
def listar_anuncios():
    anuncios = db.session.scalars(db.select(Anuncio)).all()
    return render_template('anuncios_lista.html', anuncios=anuncios, titulo="Lista de Anúncios")

@app.route("/anuncio/criar", methods=['POST'])
def criar_anuncio():
    novo_anuncio = Anuncio(
        nome=request.form.get('nome'),
        descricao=request.form.get('descricao'),
        quantidade=int(request.form.get('quantidade')),
        preco=float(request.form.get('preco')),
        categoria_id=int(request.form.get('categoria_id')),
        usuario_id=int(request.form.get('usuario_id'))
    )
    db.session.add(novo_anuncio)
    db.session.commit()
    return redirect(url_for('listar_anuncios'))

@app.route("/anuncio/editar/<int:id>", methods=['GET', 'POST'])
def editar_anuncio(id):
    anuncio_obj = db.get_or_404(Anuncio, id)
    categorias = db.session.scalars(db.select(Categoria)).all()
    usuarios = db.session.scalars(db.select(Usuario)).all()
    if request.method == 'POST':
        anuncio_obj.nome = request.form.get('nome')
        anuncio_obj.descricao = request.form.get('descricao')
        anuncio_obj.quantidade = int(request.form.get('quantidade'))
        anuncio_obj.preco = float(request.form.get('preco'))
        anuncio_obj.categoria_id = int(request.form.get('categoria_id'))
        anuncio_obj.usuario_id = int(request.form.get('usuario_id'))
        db.session.commit()
        return redirect(url_for('listar_anuncios'))
    return render_template('editar_anuncio.html', anuncio=anuncio_obj, categorias=categorias, usuarios=usuarios, titulo="Editar Anúncio")

@app.route("/anuncio/deletar/<int:id>")
def deletar_anuncio(id):
    anuncio_obj = db.get_or_404(Anuncio, id)
    db.session.delete(anuncio_obj)
    db.session.commit()
    return redirect(url_for('listar_anuncios'))


# CRUD de pergunta e resposta
@app.route("/anuncios/pergunta")
def pergunta():
    perguntas = db.session.scalars(db.select(Pergunta)).all()
    anuncios = db.session.scalars(db.select(Anuncio)).all()
    usuarios = db.session.scalars(db.select(Usuario)).all()
    return render_template('pergunta.html', perguntas=perguntas, anuncios=anuncios, usuarios=usuarios, titulo="Perguntas e Respostas")

@app.route("/pergunta/criar", methods=['POST'])
def criar_pergunta():
    nova_pergunta = Pergunta(
        conteudo=request.form.get('conteudo'),
        anuncio_id=int(request.form.get('anuncio_id')),
        usuario_id=int(request.form.get('usuario_id'))
    )
    db.session.add(nova_pergunta)
    db.session.commit()
    return redirect(url_for('pergunta'))

@app.route("/pergunta/editar/<int:id>", methods=['GET', 'POST'])
def editar_pergunta(id):
    pergunta_obj = db.get_or_404(Pergunta, id)
    anuncios = db.session.scalars(db.select(Anuncio)).all()
    usuarios = db.session.scalars(db.select(Usuario)).all()
    if request.method == 'POST':
        pergunta_obj.conteudo = request.form.get('conteudo')
        pergunta_obj.anuncio_id = int(request.form.get('anuncio_id'))
        pergunta_obj.usuario_id = int(request.form.get('usuario_id'))
        db.session.commit()
        return redirect(url_for('pergunta'))
    return render_template('editar_pergunta.html', pergunta=pergunta_obj, anuncios=anuncios, usuarios=usuarios, titulo="Editar Pergunta")

@app.route("/pergunta/deletar/<int:id>")
def deletar_pergunta(id):
    pergunta_obj = db.get_or_404(Pergunta, id)
    db.session.delete(pergunta_obj)
    db.session.commit()
    return redirect(url_for('pergunta'))

@app.route("/resposta/criar", methods=['POST'])
def criar_resposta():
    nova_resposta = Resposta(
        conteudo=request.form.get('conteudo'),
        pergunta_id=int(request.form.get('pergunta_id'))
    )
    db.session.add(nova_resposta)
    db.session.commit()
    return redirect(url_for('pergunta'))

@app.route("/resposta/editar/<int:id>", methods=['GET', 'POST'])
def editar_resposta(id):
    resposta_obj = db.get_or_404(Resposta, id)
    if request.method == 'POST':
        resposta_obj.conteudo = request.form.get('conteudo')
        db.session.commit()
        return redirect(url_for('pergunta'))
    return render_template('editar_resposta.html', resposta=resposta_obj, titulo="Editar Resposta")

@app.route("/resposta/deletar/<int:id>")
def deletar_resposta(id):
    resposta_obj = db.get_or_404(Resposta, id)
    db.session.delete(resposta_obj)
    db.session.commit()
    return redirect(url_for('pergunta'))


# CRUD de compra
@app.route("/anuncios/compra")
def compra():
    compras = db.session.scalars(db.select(Compra)).all()
    anuncios = db.session.scalars(db.select(Anuncio)).all()
    usuarios = db.session.scalars(db.select(Usuario)).all()
    return render_template('compra.html', compras=compras, anuncios=anuncios, usuarios=usuarios, titulo="Realizar Compra")

@app.route("/compra/criar", methods=['POST'])
def criar_compra():
    anuncio_id = int(request.form.get('anuncio_id'))
    usuario_id = int(request.form.get('usuario_id'))
    quantidade = int(request.form.get('quantidade'))
    
    anuncio_obj = db.session.get(Anuncio, anuncio_id)
    if anuncio_obj:
        preco_unitario = anuncio_obj.preco
        valor_total = preco_unitario * quantidade
        nova_compra = Compra(
            quantidade=quantidade,
            preco_unitario=preco_unitario,
            valor_total=valor_total,
            anuncio_id=anuncio_id,
            usuario_id=usuario_id
        )
        db.session.add(nova_compra)
        if anuncio_obj.quantidade >= quantidade:
            anuncio_obj.quantidade -= quantidade
        db.session.commit()
    return redirect(url_for('compra'))

@app.route("/compra/editar/<int:id>", methods=['GET', 'POST'])
def editar_compra(id):
    compra_obj = db.get_or_404(Compra, id)
    anuncios = db.session.scalars(db.select(Anuncio)).all()
    usuarios = db.session.scalars(db.select(Usuario)).all()
    if request.method == 'POST':
        compra_obj.quantidade = int(request.form.get('quantidade'))
        compra_obj.anuncio_id = int(request.form.get('anuncio_id'))
        compra_obj.usuario_id = int(request.form.get('usuario_id'))
        anuncio_obj = db.session.get(Anuncio, compra_obj.anuncio_id)
        if anuncio_obj:
            compra_obj.preco_unitario = anuncio_obj.preco
            compra_obj.valor_total = compra_obj.preco_unitario * compra_obj.quantidade
        db.session.commit()
        return redirect(url_for('compra'))
    return render_template('editar_compra.html', compra=compra_obj, anuncios=anuncios, usuarios=usuarios, titulo="Editar Compra")

@app.route("/compra/deletar/<int:id>")
def deletar_compra(id):
    compra_obj = db.get_or_404(Compra, id)
    db.session.delete(compra_obj)
    db.session.commit()
    return redirect(url_for('compra'))


# CRUD de favoritos
@app.route("/anuncios/favoritos")
def favoritos():
    favoritos_lista = db.session.scalars(db.select(Favorito)).all()
    anuncios = db.session.scalars(db.select(Anuncio)).all()
    usuarios = db.session.scalars(db.select(Usuario)).all()
    return render_template('favoritos.html', favoritos=favoritos_lista, anuncios=anuncios, usuarios=usuarios, titulo="Meus Favoritos")

@app.route("/favorito/criar", methods=['POST'])
def criar_favorito():
    novo_fav = Favorito(
        anuncio_id=int(request.form.get('anuncio_id')),
        usuario_id=int(request.form.get('usuario_id'))
    )
    db.session.add(novo_fav)
    db.session.commit()
    return redirect(url_for('favoritos'))

@app.route("/favorito/editar/<int:id>", methods=['GET', 'POST'])
def editar_favorito(id):
    favorito_obj = db.get_or_404(Favorito, id)
    anuncios = db.session.scalars(db.select(Anuncio)).all()
    usuarios = db.session.scalars(db.select(Usuario)).all()
    if request.method == 'POST':
        favorito_obj.anuncio_id = int(request.form.get('anuncio_id'))
        favorito_obj.usuario_id = int(request.form.get('usuario_id'))
        db.session.commit()
        return redirect(url_for('favoritos'))
    return render_template('editar_favorito.html', favorito=favorito_obj, anuncios=anuncios, usuarios=usuarios, titulo="Editar Favorito")

@app.route("/favorito/deletar/<int:id>")
def deletar_favorito(id):
    fav_obj = db.get_or_404(Favorito, id)
    db.session.delete(fav_obj)
    db.session.commit()
    return redirect(url_for('favoritos'))


# Relatórios
@app.route("/relatorios/vendas")
def relVendas():
    compras = db.session.scalars(db.select(Compra)).all()
    total_vendas = sum(c.valor_total for c in compras)
    return render_template('relVendas.html', compras=compras, total_vendas=total_vendas, titulo="Relatório de Vendas")

@app.route("/relatorios/compras")
def relCompras():
    compras = db.session.scalars(db.select(Compra)).all()
    total_compras = sum(c.valor_total for c in compras)
    return render_template('relCompras.html', compras=compras, total_compras=total_compras, titulo="Relatório de Compras")


if __name__ == '__main__':
    app.run(debug=True)
